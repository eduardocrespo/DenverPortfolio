ProxyManager Bridge
===================

Provides integration for [ProxyManager][1] with various Symfony components.

Resources
---------

You can run the unit tests with the following command:

    $ cd path/to/Symfony/Bridge/ProxyManager/
    $ composer install
    $ phpunit

[1]: https://github.com/Ocramius/ProxyManager
