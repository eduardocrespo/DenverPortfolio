<?php

$container->loadFromExtension('framework', array(
    'profiler' => array(
        'enabled' => true,
    ),
));
