<?php echo $view['form']->block($form, 'widget_attributes') ?>
